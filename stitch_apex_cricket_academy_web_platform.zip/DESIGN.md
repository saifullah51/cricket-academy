---
name: Prestigious Cricket Academy Visual System
colors:
  surface: '#0c1512'
  surface-dim: '#0c1512'
  surface-bright: '#323b37'
  surface-container-lowest: '#07100d'
  surface-container-low: '#141d1a'
  surface-container: '#18221e'
  surface-container-high: '#222c28'
  surface-container-highest: '#2d3733'
  on-surface: '#dae5df'
  on-surface-variant: '#bfc9c2'
  inverse-surface: '#dae5df'
  inverse-on-surface: '#29322f'
  outline: '#8a938d'
  outline-variant: '#404944'
  surface-tint: '#96d3b8'
  primary: '#96d3b8'
  on-primary: '#003828'
  primary-container: '#0a4d39'
  on-primary-container: '#81bda3'
  inverse-primary: '#2d6953'
  secondary: '#e9c349'
  on-secondary: '#3c2f00'
  secondary-container: '#af8d11'
  on-secondary-container: '#342800'
  tertiary: '#8ed5b3'
  on-tertiary: '#003826'
  tertiary-container: '#004e36'
  on-tertiary-container: '#79bf9e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b2f0d4'
  primary-fixed-dim: '#96d3b8'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#10503c'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#aaf2ce'
  tertiary-fixed-dim: '#8ed5b3'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005138'
  background: '#0c1512'
  on-background: '#dae5df'
  surface-variant: '#2d3733'
typography:
  display-hero:
    fontFamily: Oswald
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 76px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Oswald
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Oswald
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.01em
  headline-xl-mobile:
    fontFamily: Oswald
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: 0em
  headline-lg:
    fontFamily: Oswald
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: 0.01em
  headline-md:
    fontFamily: Oswald
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: 0.02em
  headline-sm:
    fontFamily: Oswald
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0.02em
  stat-counter-lg:
    fontFamily: Oswald
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  stat-counter-md:
    fontFamily: Oswald
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  body-xl:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-caps:
    fontFamily: Oswald
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.12em
  label-stat:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  space-4xl: 6rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  margin-mobile: 1rem
  margin-tablet: 2rem
  margin-desktop: 3.5rem
---

## Brand & Style

This design system expresses the apex of modern cricket mastery: elite athletic conditioning coupled with the storied heritage and regal prestige of the gentleman’s game. The visual narrative balances raw stadium power with boardroom-grade sporting aristocracy. The interface feels architectural, decisive, and pristine—reminiscent of bespoke pavilion architecture, floodlit night matches, and the exacting micro-metrics of world-class biomechanics.

The target audience includes aspiring national players, high-performance coaches, scouts, elite patrons, and tournament administrators. The interface avoids frivolous ornamentation or casual gamification; every screen commands authority, rigor, and technical superiority. 

The aesthetic style merges **Modern High-Performance Athletic** with **Refined Architectural Glassmorphism**:
- Ultra-crisp structural framing with dark onyx grounding and deep pavilion greens.
- Tactile glassmorphic stat modules and accreditation shields featuring micro-borders and directional metallic glints.
- Condensed, authoritative typographic scale paired with precision monospaced stats telemetry.
- Architectural lines evocative of crease markings, turf striping, and pavilion timber slats.

## Colors

The chromatic architecture is anchored in traditional test match greens, dark pitch-night onyx, and high-spec athletic metallics. The system is engineered primarily for dark mode to recreate the high-focus, dramatic atmosphere of floodlit elite stadiums.

### Palette Roles & Specific Tokens

- **Pitch Turf Deep Green (`#0A4D39` / `#063B2B`)**: The primary brand surface and dominant brand anchor. Used for primary CTA surfaces, key card flood fills, and structural brand highlights.
- **Trophy Gold (`#D4AF37` / `#E5C158`)**: The athletic accent. Reserved strictly for achievements, performance indicators, accreditation badges, leaderboards, and interactive focus moments. Never overused as general background fills.
- **Pitch Turf Active (`#115E43`)**: Tertiary interactive state color, used for hover states, selected card perimeters, and active performance data graphs.
- **Midnight Onyx Base (`#07100D`) & Elevated Onyx (`#0D1612`)**: The foundational canvas. Provides immense contrast, making statistics and athletic imagery stand out with cinematic intensity.
- **Warm Cream Off-White (`#F4F5F3`)**: Primary text and sharp foreground graphic elements. Softer than sterile digital white, evoking traditional cricket flannels and premium archival parchment.
- **Boundary White (`#FFFFFF`)**: High-contrast callouts, stat figures, and pristine crease dividers.
- **Boundary Line Glass Border (`rgba(244, 245, 243, 0.12)`)**: Structural hairline borders that emulate chalked boundary marks.

## Typography

The typographic hierarchy establishes instant contrast: condensed, high-impact athletic headings via **Oswald** paired with the uncompromised legibility and metric precision of **Inter**.

### Usage Guidelines
- **Headlines & Metric Figures (`Oswald`)**: Always set all uppercase for card badges, category tags, player positions, and stat counters. Use standard title case for large section narrative headlines. Oswald carries the condensed weight of scoreboard displays and pavilion honor boards.
- **Body Text & Biometric Data (`Inter`)**: Use for commentary, player profiles, training regimen descriptions, and tabular breakdowns. Retains optical clarity against dark stadium backgrounds.
- **Telemetry & Stats**: Numerical readouts (Strike Rates, Bowling Averages, Release Speeds, Run Tallies) must utilize `stat-counter-lg` or `stat-counter-md` in `Oswald` with tabular figures turned on (`font-feature-settings: "tnum"`).

## Layout & Spacing

The layout is built around a rigorous 12-column architectural grid inspired by sports pitch geometry, structural stadium beams, and classical pavilion colonnades. 

### Breakpoints & Fluid Grid Dynamics
- **Mobile (< 768px)**: 4 columns, `margin-mobile` (16px), `gutter-mobile` (16px). All sports cards collapse to single-column full-width tiles or horizontally scrollable rosters with snapping behavior.
- **Tablet (768px – 1024px)**: 8 columns, `margin-tablet` (32px), `gutter-desktop` (24px). Analytical split screens (video analysis left, telemetric telemetry right) collapse to a 5:3 or stacked hierarchy.
- **Desktop (1025px+)**: 12 columns, max-width 1440px centered, `margin-desktop` (56px), `gutter-desktop` (24px). Accommodates comprehensive multi-pane views: academy player lists, metric radar charts, fixture tracks, and master scorecards simultaneously.

### Spacing Rhythm
Built upon an uncompromising **4px/8px modular cadence**. Structural component padding favors a compressed, athletic density: stat pods use high horizontal padding with dense vertical margins to simulate physical dugout boards and professional broadcast overlays.

## Elevation & Depth

Visual depth is achieved through an architectural combination of tinted atmospheric glass, deep forest backdrop illumination, and fine metallic edge reflections.

### Surface Tiers & Tonal Layers
1. **Pitch Canvas (Level 0)**: Midnight Onyx (`#07100D`). Solid background with faint ambient radial gradients of Deep Turf Green (`rgba(10, 77, 57, 0.25)`) positioned in upper corners to replicate floodlight wash.
2. **Pavilion Deck (Level 1)**: Elevated Onyx (`#0D1612`) with a single hairline border (`1px solid rgba(244, 245, 243, 0.08)`). Used for master containers, calendar bars, and secondary modules.
3. **Sports Card Glass (Level 2)**: Translucent Forest Glass (`rgba(10, 77, 57, 0.45)`) backed with a `16px` backdrop blur (`backdrop-filter: blur(16px)`). Bound by a dual-tone edge: top/left border `1px solid rgba(212, 175, 55, 0.35)` and bottom/right border `1px solid rgba(244, 245, 243, 0.06)`.
4. **Accreditation Floating Shields (Level 3)**: High-translucency glass (`rgba(13, 22, 18, 0.85)`) elevated by an ambient tinted shadow (`0 20px 40px -10px rgba(0, 0, 0, 0.7), 0 0 20px rgba(212, 175, 55, 0.15)`).

### Shadows
Shadows never use sterile neutral grays. They are saturated with Deep Onyx (`rgba(4, 10, 8, 0.9)`) and subtly tinted with Trophy Gold (`rgba(212, 175, 55, 0.1)`) on interactive hover or active victory states.

## Shapes

The academy visual system maintains a **Soft Architectural (`1`)** shape language. Elements favor crisp, disciplined corners over bulbous, playful curves. Corners are dialed back to 4px (`0.25rem`) and 8px (`0.5rem`) to reinforce physical precision, technical discipline, and sporting rigor.

### Shape Hierarchy
- **Base Components (Inputs, Small Badges, Counters)**: `4px` (`0.25rem`). Minimal rounding yields a clean, engineered tool appearance.
- **Cards & Data Modules**: `8px` (`0.5rem`). Balances modern sleekness with structural solidity.
- **Accreditation Emblems & Shields**: Distinctive chamfered or angled geometry (12px diagonal top-right cut) to evoke heraldic academy crests and modern tournament trophies.
- **Status Pills**: Fully pill-shaped (`9999px`) only when indicating live status (e.g., "IN NETS", "MATCH READY", "LIVE RADAR").

## Components

### 1. Buttons
- **Primary Athletic CTA**: Deep Forest Green (`#0A4D39`) base with a refined Trophy Gold bottom lip border (`2px solid #D4AF37`) and Warm Cream text (`#F4F5F3`) in `Oswald` Bold uppercase with letter-spacing `0.08em`. Hover activates a subtle inner luminescence (`box-shadow: inset 0 0 12px rgba(212, 175, 55, 0.3)`) and shifts background to `#115E43`.
- **Trophy Action (Special)**: Solid Trophy Gold (`#D4AF37`) fill with Midnight Onyx text (`#07100D`). Reserved for enrollment, match confirmation, and masterclass bookings.
- **Secondary Glass**: Midnight Onyx surface with `1px` translucent border (`rgba(244, 245, 243, 0.16)`), hovering to reveal a green tint overlay.

### 2. Sports Performance Cards (Player & Coach Tiles)
- Built with a 3:4 portrait aspect ratio featuring high-contrast athlete imagery.
- The bottom 45% is treated with an architectural dark green glass gradient scrim (`linear-gradient(to top, #07100D 0%, rgba(10, 77, 57, 0.7) 60%, transparent 100%)`).
- Overlaid with Oswald stat counters (Release Speed, Batting Strike Rate, Century Tallies) formatted with hairline gold vertical dividers.
- Top-right corner anchors an accreditation badge or academy cap number.

### 3. Glassmorphism Badges & Accreditation Emblems
- Small, ultra-crisp indicators for credentials ("ICC LEVEL 3", "ELITE SQUAD", "PACE LAB ACCREDITED").
- Composed of frosted translucent black-green (`rgba(6, 59, 43, 0.6)`) with `8px` blur, bordered with micro-thin metallic lines (`1px solid rgba(212, 175, 55, 0.5)`).
- Contains monochrome iconography rendered in Trophy Gold.

### 4. Stats Counters & Metric Displays
- Numeric readings use high-scale condensed numerals (`Oswald`) in Boundary White (`#FFFFFF`).
- Accompanying micro-labels ("BOWLING AVG", "ECONOMY", "REACTION TIME (MS)") are placed underneath in `Inter` SemiBold 11px uppercase in Trophy Gold or muted cream.
- Bounded within low-contrast outline grids that mirror stadium electronic scoreboards.

### 5. Input Fields
- Dark Onyx fill (`#0D1612`) with a sharp `4px` corner radius.
- Resting border: `1px solid rgba(244, 245, 243, 0.12)`.
- Focus state: `1px solid #D4AF37` accompanied by an ambient gold turf glow (`0 0 0 3px rgba(212, 175, 55, 0.15)`).
- Placeholders in muted chalk green-grey (`rgba(244, 245, 243, 0.4)`).

### 6. Checkboxes & Radio Buttons
- Precision square checkboxes (`4px` radius) and circular radios with Deep Onyx backgrounds and boundary borders.
- Checked state fills with Deep Forest Green (`#0A4D39`) and displays a crisp Trophy Gold tick or inner pip.

### 7. Academy Specific Components
- **Pitch Biometric Trackers**: Segmented heatmaps and pitch map visualizations utilizing pitch green turf overlays and gold impact strike zones.
- **Pavilion Honor Board**: Monospaced tabular list view featuring gold typography for milestone records and cream text for standard player annals.